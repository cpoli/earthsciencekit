"""
Boltwood's uranium-lead ages (1907)
===================================

Boltwood noticed that uranium minerals always contain lead, and more of it in
older rocks. Taking lead as the end of the uranium decay series, he turned the
lead-to-uranium ratio of minerals into ages of hundreds of millions to billions
of years, the first radiometric ages. With a known decay constant the age is
``log(1 + D/P) / lambda``; Boltwood's simpler ratio-over-rate is the first term
of that logarithm and overestimates old ages.
"""

import matplotlib.pyplot as plt
import numpy as np

from earthsciencekit.constants import LAMBDA_U238
from earthsciencekit.units import convert
from earthsciencekit.volcanology import radiometric_age

ratio = np.linspace(0, 0.6, 121)  # radiogenic 206Pb atoms per 238U atom
age = convert(radiometric_age(ratio, LAMBDA_U238), "s", "Ma")
linear = convert(ratio / LAMBDA_U238, "s", "Ma")
assert np.all(age <= linear) and np.isclose(age[1], linear[1], rtol=3e-3)
assert np.isclose(convert(radiometric_age(np.e - 1, LAMBDA_U238), "s", "Ma"), 1e-6 / 1.55125e-10)  # one mean life

minerals = np.array([0.05, 0.12, 0.2, 0.3])  # synthetic Pb/U ratios
fig, ax = plt.subplots()
ax.plot(ratio, age, label="log(1 + D/P) / lambda")
ax.plot(ratio, linear, "--", label="D / (P lambda), Boltwood's form")
ax.plot(minerals, convert(radiometric_age(minerals, LAMBDA_U238), "s", "Ma"), "ko", label="synthetic minerals")
ax.set(xlabel="206Pb / 238U", ylabel="age [Ma]", title="Lead accumulates in uranium minerals")
ax.legend()

plt.show()
